/*-----------------------------------------------------------------------------------*/
/* Free Travel WordPress Theme */
/*-----------------------------------------------------------------------------------*/

Theme Name      :   Prevalent
Theme URI       :   https://gracethemes.com/themes/free-travel-wordpress-theme/
Version         :   1.6.0
Tested up to    :   WP 4.7.2
Author          :   Grace Themes
Author URI      :   https://www.gracethemes.com/

license         :   GNU General Public License v3.0
License URI     :   http://www.gnu.org/licenses/gpl.html

/*-----------------------------------------------------------------------------------*/
/* About Author - Contact Details */
/*-----------------------------------------------------------------------------------*/

email       :   support@gracethemes.com

/*-----------------------------------------------------------------------------------*/
/* Theme Resources */
/*-----------------------------------------------------------------------------------*/

Theme is Built using the following resource bundles.

1 - All js that have been used are within folder /js of theme.
2 - jQuery Nivo Slider
	Copyright 2012, Dev7studios, under MIT license
	http://nivo.dev7studios.com


3 - Montserrat :https://www.google.com/fonts/specimen/Montserrat
	License: Distributed under the terms of the Apache License, version 2.0 		
	http://www.apache.org/licenses/LICENSE-2.0.html


4 - Images used from Pixabay.
    Pixabay provides images under CC0 license 
   (https://creativecommons.org/about/cc0)

	Slider Images:	
	https://pixabay.com/en/maldives-ocean-sea-island-boat-1734242/
	
	Other Images:
	https://pixabay.com/en/bridge-general-rafael-urdaneta-539498/
	https://pixabay.com/en/autumn-landscape-nature-golden-219972/
	https://pixabay.com/en/flower-color-street-photography-1358038/
	https://pixabay.com/en/girl-sea-beach-young-summer-429380/
	
5 - Font-Awesome
	Font Awesome 4.5.0 by @davegandy - http://fontawesome.io - @fontawesome
 	License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
	

For any help you can mail us at support[at]gracethemes.com

/*-----------------------------------------------------------------------------------*/
/* Copyright */
/*-----------------------------------------------------------------------------------*/

Prevalent WordPress Theme is based on Underscores http://underscores.me/, (C) 2012-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
Prevalent is derived from Underscores, distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see < http://www.gnu.org/licenses/ >